import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer, MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  customer: Customer;
  queryParams: any;
  id = 12;
  constructor(private myservice: MyserviceService, private router: Router) { }

  ngOnInit() {
  }
  onSubmit(addcus: Customer): any {

    console.log(addcus.userName + " " + addcus.password);
    this.myservice.getCustomerLogin(addcus).subscribe(data => {
      console.log(data);
      this.customer = data;
      if (data != null) {
        this.router.navigate(['/profile',this.customer.customerId]);
      }
      else {
        alert("Invalid PassWord or Username");
      }
    });

  }
}
