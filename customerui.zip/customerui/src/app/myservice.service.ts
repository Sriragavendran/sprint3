import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updateCustomer: Customer;
  constructor(private httpService: HttpClient) { }
  public getCustomer() {
    console.log("ins service get Customer");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Customer>("http://localhost:8586/customer/all");
  }
  public getCustomerByid(customerId:number){
    console.log('get by id service');
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Customer>("http://localhost:8586/customer/view/" + customerId);
  }
  public getCustomerLogin(addCus:Customer){
    console.log('login'+addCus.userName);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Customer>("http://localhost:8586/customer/login/" + addCus.userName+"/"+addCus.password);
  }
  public addCus(addcus: Customer) {
    console.log("ins service add");
    console.log(addcus);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8586/customer/create", addcus,  { headers, responseType: 'text'});
  }
  
  public update(updateCustomer: Customer) {
    this.updateCustomer = updateCustomer;
  }
  public updateMethod() {
    return this.updateCustomer;
  }
  public onUpdate(updatecus: Customer) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:8586/customer/update", updatecus,  { headers, responseType: 'text'});
  }
  delete(customerId: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:8586/customer/delete/" + customerId,  { headers, responseType: 'text'});
  }

}
export class Customer {
  customerId: number;
  customerName: string;
  customerMobile: string;
  customerEmail: string;
  customerAddress: string;
  userName: string;
  password:string;
}