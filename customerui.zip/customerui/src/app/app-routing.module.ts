import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListCustomerComponent } from './list-customer/list-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';


const routes: Routes = [{ path: 'listcus', component: ListCustomerComponent },
{ path: 'addcus', component: CreateCustomerComponent },
{ path: '', component: HomepageComponent },
{path:'profile/:id',component:ProfileComponent},
{ path: 'updatecus', component: UpdateCustomerComponent },
{ path: 'homepage', component: HomepageComponent },
{ path: 'contact', component: ContactUSComponent },
{ path: 'login', component: LoginComponent },
{path:'profile', component:ProfileComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
