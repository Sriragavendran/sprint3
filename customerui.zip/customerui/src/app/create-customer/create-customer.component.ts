import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Customer} from '../myservice.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.css']
})
export class CreateCustomerComponent implements OnInit {
  message: string;

  constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {
  }
  onSubmit(addcus:Customer):any{
    var selection=confirm("Confirm your Details");
    if(selection){
    console.log("Data added Succesfully!!");
    console.log(addcus);
     this.myservice.addCus(addcus).subscribe(data => {
      
      this.router.navigate(['/profile']);
    });
  }
  }

}
