import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { Customer, MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  message: string;
  customers: object;
  cus: object;
   
  constructor(private myservice: MyserviceService, private router: Router, private route: ActivatedRoute) {

  }

  ngOnInit(): any {
    let id:number;
    console.log(this.route + "....");
    this.route.params.subscribe(params => {
      id = params['id'];
      console.log(id + " qq");
    })
    this.myservice.getCustomerByid(id).subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }

  handleSuccessfulResponse(response) {
    console.log(response + " get by id");
    this.customers = response;
  }
  update(updateCustomer: Customer) {
    this.myservice.update(updateCustomer);
    this.router.navigate(['/updatecus']);
  }
  delete(deleteCustomer: Customer): any {
    var selection = confirm("Are you sure to delete!!")
    if (selection) {
      //this.customers.splice(this.customers.indexOf(deleteCustomer), 1);
      this.myservice.delete(deleteCustomer.customerId).subscribe(data => {
        alert(data);

      });
    }
    this.router.navigate(['/homepage']);
  }
}
